'use strict';






var express = require('express');
const bodyParser = require('body-parser');
var app = express();
var cors = require('cors');

app.use(cors());




app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

const fs = require('fs');

app.get('/getLogo', function (req, res) {
  var p = "DB/images/logo.jpg";
  fs.readFile(p, function (err, data) {

    res.writeHead(200, { 'Content-Type': 'image/jpeg' });
    res.end(data); // Send the file data to the browser.

  });

})



///////////////-USERS-//////////////////////////////
app.get('/getUser', function (req, res) {
  let rawdata = fs.readFileSync('DB/Users.json');
  // res.end(rawdata);
  let users = JSON.parse(rawdata);
  let u = users.find(x => x.UserName == req.query.uName && x.Password == req.query.pass)
  if (u) {
    console.log("User found!!");
    res.end(JSON.stringify(u));
  }
  else {
    console.log("user not found !!!!");
    res.send("false");
  }

})
app.post('/addUser', function (req, res) {
  // First read existing users.
  let rawdata = fs.readFileSync('DB/Users.json');
  let users = JSON.parse(rawdata);
  console.log(req.body);

  var userExists = users.find(x => x.ID == req.body.user.ID);
  if (!userExists) {
    users.push(req.body.user);
    fs.writeFileSync('DB/Users.json',JSON.stringify(users) );
    res.end("true");
  }
  else {
    res.end("false");//user allready exists
  }


})

/////////////////-PRODUCTS-/////////////////////////////////////
app.get('/getProductImage', function (req, res) {
  var p = "DB/images/p" + req.query.pid + ".jpg";
  fs.readFile(p, function (err, data) {

    res.writeHead(200, { 'Content-Type': 'image/jpeg' });
    res.end(data); // Send the file data to the browser.

  });

})

app.get('/getProducts', function (req, res) {
  let rawdata = fs.readFileSync('DB/Products.json');
  res.end(rawdata);
  // let users = JSON.parse(rawdata);
  // res.end( users );

})


////////////////////////////////////////////

//forgot password ///////
app.get('/sendmail', function (req, res) {
  // First read existing users.
  let rawdata = fs.readFileSync('DB/Users.json');
  let users = JSON.parse(rawdata);

  var userExists = users.find(x => x.ID == req.body.user.ID);
  if (!userExists) {
    res.end("false");
  }
  else {
    //send an Email
    // var nodemailer = require('nodemailer');

    // var transporter = nodemailer.createTransport({
    //   host: 'smtp.gmail.com',
    //   port: 587,
    //   secure: false,
    //   requireTLS: true,
    //   auth: {
    //     user: 'YourEmail@gmail.com',
    //     pass: '*********'
    //   }
    //   //אפשר גישה נמוכה לכניסה לגימייל
    //   //https://myaccount.google.com/lesssecureapps?pli=1&rapt=AEjHL4PT_NBxenZJHNmPmdHom67fW6AahFvUj6yTpEhXG-WTsdEBxuqHqcM8ZxgXQm7MzFYH15SJAYcJk4sMQg6_BNXpFILIxQ
    // });

    // var mailOptions = {
    //   from: 'mordico25@gmail.com',
    //   to: 'mordico25@gmail.com',
    //   subject: ' vitamins shop',
    //   html: '<h1>Welcome</h1><p> to the vitamins shop!</p>'
    // };
    // transporter.sendMail(mailOptions, function (error, info) {
    //   if (error) {
    //     console.log(error);
    //   } else {
    //     console.log('Email sent: ' + info.response);
    //   }
    // });
    res.end("true");
  }




})


//////////////////////////////////

const hostname = '127.0.0.1';
const port = 3000;

var server = app.listen(port, hostname, function () {
  var host = server.address().address
  var port = server.address().port
  console.log("Example app listening at http://%s:%s", host, port)
})


// const http = require('http');
// 
// const server = http.createServer((req, res) => {
//   res.statusCode = 200;
//   //res.setHeader('Content-Type', 'text/plain');
//   //res.end('Hello World');
// });
// server.listen(port, hostname, () => {
//   console.log(`Server running at http://${hostname}:${port}/`);
// });


