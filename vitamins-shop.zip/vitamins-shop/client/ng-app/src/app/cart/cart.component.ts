import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { AlertDialogComponent } from '../core/components/alert-dialog/alert.dialog.component';
import { AppService } from '../core/services/app.service';
import { Product } from '../products/models/Product';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {

  constructor(private appservice: AppService,
    private dialog:MatDialog,
    private router:Router) { }

  ngOnInit(): void {
  }

  get productList() {
    return this.appservice.cart.produtsList;
  }
  get total() {
    return this.appservice.cart.getTotal();
  }
  addToCart(p: Product) {
    this.appservice.cart.addToCart(p);
  }
  substructFromCart(p: Product) {
    this.appservice.cart.subtructFromCart(p);
  }
  getProductImage(p: Product) {
    return 'http://localhost:3000/getProductImage?pid=' + p.productId;
  }

  sendOrder(){

    this.dialog.open(AlertDialogComponent,{
      width:"30vw",
      height:"25vh",
      data:{msg:"Your order has been registered. Our representative will get in touch with you. Thanks."}
    }).afterClosed().subscribe(x=>{

      this.router.navigate(["/products"]);
    })
  }

}
