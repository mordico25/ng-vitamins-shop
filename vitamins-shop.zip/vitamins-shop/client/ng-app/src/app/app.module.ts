import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/components/login/login.component';
import { HomeComponent } from './home/home.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AppService } from './core/services/app.service';
import { LoginModule } from './login/login.module';
import { HttpClient } from '@angular/common/http';
import { CoreModule } from './core/core.module';
import { ProductModule } from './products/products.module';
import { CommonModule } from '@angular/common';
import { CartComponent } from './cart/cart.component';
import { SearchComponent } from './search/components/search.component';


@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    CartComponent,
    SearchComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    CoreModule,
    LoginModule,
    ProductModule,

  ],
  providers: [AppService, HttpClient],
  bootstrap: [AppComponent]
})
export class AppModule { }
