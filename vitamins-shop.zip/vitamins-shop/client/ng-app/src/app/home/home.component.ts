import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppService } from '../core/services/app.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent  {


  constructor(private appService:AppService,
    private router:Router){

  }

  get CurrUser(){
    return this.appService.CurrentUser;
  }
  logout(){
    this.appService.CurrentUser=null;
  }
  get shopLogo(){
    return "http://localhost:3000/getLogo";
  }
  gotoToCart(){

    this.router.navigate(["/cart"])
  }

}
