import { Product } from "src/app/products/models/Product";

export class Cart {
    produtsList: ProductInCart[] = [];
    addToCart(newP: Product) {
        let p = this.produtsList.find(x => x.product.productId == newP.productId);
        if (p) {
            p.amount++;
        }
        else {
            let p=new ProductInCart();
            p.product=Object.assign({},newP) ;
            p.amount= 1;
            this.produtsList.push(p);
        }
    }
    subtructFromCart(_P: Product) {
        let p = this.produtsList.find(x => x.product.productId == _P.productId);
        p.amount--;
        if(p.amount==0){
         let ind=   this.produtsList.findIndex(x => x.product.productId == _P.productId);
         this.produtsList.splice(ind,1);
         console.log(this.produtsList);
         
        }
      
    }
    getTotal(){
        if(this.produtsList.length==0) return 0;
        let tot= this.produtsList.reduce((a,b)=>{
            return a+(b.product.price*b.amount);
        },0);

        return tot;
    }
}
export class ProductInCart {
    product:Product;
    amount: number;
    
}