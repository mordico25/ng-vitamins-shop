export class User{
    UserName:string;
    Password:string;
    Phone:string;
    ID:string;
    Email:string;
    Address:string;

    constructor(_name:string,_pass:string,_email:string,_phone:string,_address:string,_id:string){

        this.UserName=_name;
        this.Password=_pass;
        this.Email=_email;
        this.Phone=_phone;
        this.Address=_address;
        this.ID=_id;
    }
}



