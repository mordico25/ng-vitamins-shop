import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { Product } from 'src/app/products/models/Product';
import { Cart } from '../models/Cart';
import { User } from '../models/user';
import { AppProxyService } from './app.proxy.service';

@Injectable()
export class AppService {

  CurrentUser:User=null;
  Users:User[]=[];
  productList:Product[]=[];
  cart:Cart=new Cart();
  refereshComponents:Subject<any>=new Subject();
  constructor(private myProxy:AppProxyService) { 
    this.myProxy.getProducts().subscribe(plist=>{
      this.productList=plist as Product[];
      this.refereshComponents.next();
    })
  }

 
}
