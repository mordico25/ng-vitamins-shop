import { CommonModule } from "@angular/common";
import { HttpClientModule } from "@angular/common/http";
import { NgModule } from "@angular/core";
import { FormsModule } from "@angular/forms";
import { MatButtonModule } from "@angular/material/button";
import { MatDialogModule } from "@angular/material/dialog";
import { MatFormFieldModule } from "@angular/material/form-field";
import { MatInputModule } from "@angular/material/input";
import { MatTabsModule } from "@angular/material/tabs";
import { AlertDialogComponent } from "./components/alert-dialog/alert.dialog.component";
import { AppProxyService } from "./services/app.proxy.service";
import { AppService } from "./services/app.service";


const MatComponents = [
    MatTabsModule,
    MatInputModule,
    MatInputModule,
    MatFormFieldModule,
    MatButtonModule,
    MatDialogModule
]

@NgModule({
    declarations: [
        AlertDialogComponent
    ],
    imports: [
        CommonModule,
        HttpClientModule,
        FormsModule,
        MatComponents
    ],
    exports: [
        FormsModule,
        MatComponents
    ],
    providers: [
        AppService,AppProxyService
    ],

    entryComponents:[
        
    ]
})
export class CoreModule { }
