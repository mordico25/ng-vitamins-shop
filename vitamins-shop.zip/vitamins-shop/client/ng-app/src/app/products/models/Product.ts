export class Product {
    productId: number;
    productName: string;
    price: number;
    madeBy: string;
    imagePath: string;
}