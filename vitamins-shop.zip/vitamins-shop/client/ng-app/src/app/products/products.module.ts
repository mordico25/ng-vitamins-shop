import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { BrowserModule } from "@angular/platform-browser";
import { CoreModule } from "../core/core.module";
import { ProductListItemComponent } from "./components/product-list-item/product-list-item.component";
import { ProductListComponent } from "./components/product-list/product-list.component";
import { ProductProxyService } from "./services/products.proxy.service";
import { ProductComponent } from './components/product/product.component';
import { RouterModule } from "@angular/router";

// export const routs=[
//     {path:'',component:ProductListComponent},
//     {path:':pid',component:ProductComponent}
// ]

@NgModule({
    declarations: [
        ProductListItemComponent,
        ProductListComponent,
        ProductComponent
    ],
    imports: [
        CommonModule,
        CoreModule,
        // RouterModule.forChild(routs)
    ],
    exports:[
        ProductListComponent
    ],
    providers: [
        ProductProxyService
    ],

})
export class ProductModule { }
