import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
 
@Injectable()
export class ProductProxyService {
 
  constructor(private _http: HttpClient) {}
  ServerPath="http://localhost:3000/";
  
  getProducts() {
    return this._http.get(this.ServerPath+'getProducts');
  }
}