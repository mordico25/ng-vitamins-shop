import { ChangeDetectionStrategy, Component, Input, OnInit } from '@angular/core';
import { AppService } from 'src/app/core/services/app.service';
import { Product } from '../../models/Product';
import {MatDialog} from '@angular/material/dialog';
import { AlertDialogComponent } from 'src/app/core/components/alert-dialog/alert.dialog.component';
import { Router } from '@angular/router';

@Component({
  selector: 'app-product-list-item',
  templateUrl: './product-list-item.component.html',
  styleUrls: ['./product-list-item.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ProductListItemComponent implements OnInit {

  constructor(private appService: AppService,
    public dialog: MatDialog,
    public router:Router) { }

  @Input("currProduct") currProduct: Product;

  ngOnInit(): void {
  }

  get currProductImage() {

    if (this.currProduct) {
      return "http://localhost:3000/getProductImage?pid=" + this.currProduct.productId;
    }
    else return "";
  }
  get ProductName() {
    if (this.currProduct) return this.currProduct.productName;
    else return "";
  }
  get ProductPrice() {
    if (this.currProduct) return this.currProduct.price;
    else return "";
  }
  addToCart(event) {
    if(event){
      event.stopPropagation();
      event.preventDefault();
    }
    this.appService.cart.addToCart(this.currProduct);
   
      const dialogRef = this.dialog.open(AlertDialogComponent,
        {
          width: '250px',
          data: {msg: "Product added to cart successfully!"}
        }
      );
  
      dialogRef.afterClosed().subscribe(result => {
        console.log(`Dialog result: ${result}`);
      });
   
  }

  gotoProduct(event){
    this.router.navigate(["/products/"+this.currProduct.productId ]);
  }
}
