import { ChangeDetectionStrategy, ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { AppService } from 'src/app/core/services/app.service';
import { Product } from '../../models/Product';
import { ProductProxyService } from '../../services/products.proxy.service';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css'],
  changeDetection:ChangeDetectionStrategy.OnPush
})
export class ProductListComponent implements OnInit {

 
  constructor(private myProxy:ProductProxyService,
    private cdRef:ChangeDetectorRef,
    private appService:AppService) { }

  ngOnInit(): void {
    this.appService.refereshComponents.subscribe(res=>{this.cdRef.detectChanges();})
  }

  get productList(){
    return this.appService.productList;
  }

}
