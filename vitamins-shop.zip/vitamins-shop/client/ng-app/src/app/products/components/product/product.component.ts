import { chainedInstruction } from '@angular/compiler/src/render3/view/util';
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute } from '@angular/router';
import { AlertDialogComponent } from 'src/app/core/components/alert-dialog/alert.dialog.component';
import { AppService } from 'src/app/core/services/app.service';
import { Product } from '../../models/Product';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css'],
  changeDetection:ChangeDetectionStrategy.OnPush
})
export class ProductComponent implements OnInit {

  constructor(private route: ActivatedRoute,
    private appService:AppService,
    private cdRef:ChangeDetectorRef,
    private dialog:MatDialog) { }

  pid:number;
  currentProduct:Product;
  ngOnInit(): void {
    
    this.route.params.subscribe(params => {
      this.pid = params['pid'];
      this.setproduct();
    });

    this.appService.refereshComponents.subscribe(x=>{
      this.setproduct();
    })
  }

  setproduct(){
    this.currentProduct = this.appService.productList.find(x=>x.productId==this.pid);
    this.cdRef.detectChanges();
  }
  get currProductImage() {
    if (this.currentProduct) {
      return "http://localhost:3000/getProductImage?pid=" + this.currentProduct.productId;
    }
    else return "";
  }
  addToCart() {
    this.appService.cart.addToCart(this.currentProduct);
   
      const dialogRef = this.dialog.open(AlertDialogComponent,
        {
          width: '250px',
          data: {msg: "Product added to cart successfully!"}
        }
      );
   
  }

}
