import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { CoreModule } from "../core/core.module";
import { LoginComponent } from "./components/login/login.component";
import { LoginProxyService } from "./services/login.proxy.service";
import { RegisterDialogComponent } from './components/register/register.dialog.component';

@NgModule({
    declarations: [
     
      LoginComponent,
     
      RegisterDialogComponent
    ],
    imports: [
        CommonModule,
        CoreModule,
    ],
    providers: [
       LoginProxyService
    ],
   
  })
  export class LoginModule { }
  