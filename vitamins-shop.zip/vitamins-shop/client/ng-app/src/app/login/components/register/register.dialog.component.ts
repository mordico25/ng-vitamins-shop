import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { User } from 'src/app/core/models/user';
import { AppService } from 'src/app/core/services/app.service';
import { LoginProxyService } from '../../services/login.proxy.service';

@Component({
  selector: 'app-register-dialog',
  templateUrl: './registerr.dialog.component.html',
  styleUrls: ['./registerr.dialog.component.css']
})
export class RegisterDialogComponent implements OnInit {

  constructor(
    public dialogRef: MatDialogRef<RegisterDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private appService: AppService,
    private myProxy: LoginProxyService,
    private router: Router) {

  }
  ngOnInit(): void {

  }


  close() {
    this.dialogRef.close();
  }

  name: string;
  EMail: string;
  phone:string;
  address: string;
  password: string;
  id: string;

  errorStr: string = "";
  register() {
    if (this.name && this.password && this.EMail && this.id) {
      let newUser = new User(this.name, this.password, this.EMail,this.phone, this.address, this.id);
      this.myProxy.addUser(newUser).subscribe(x => {
        if (x == true) {
          this.appService.Users.push(newUser);
          this.appService.CurrentUser = newUser;
          this.appService.Users.push(newUser);
          this.appService.CurrentUser = newUser;
          this.close();
          this.router.navigate(["/Products"]);
        }
        else {
          this.errorStr = "registeration failed. please check your details and try again."
        }
      })


    }
  }

}
