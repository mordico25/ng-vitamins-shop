import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { AlertDialogComponent } from 'src/app/core/components/alert-dialog/alert.dialog.component';
import { User } from '../../../core/models/user';
import { AppService } from '../../../core/services/app.service';
import { LoginProxyService } from '../../services/login.proxy.service';
import { RegisterDialogComponent } from '../register/register.dialog.component';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  userName: string = "";
  password: string = "";
  constructor(
    public appService: AppService,
    public router: Router,
    public dialog: MatDialog,
    public myProxy: LoginProxyService) { }

  ngOnInit(): void {
  }

  errLogin:string;
  Login() {
    if (this.userName && this.password) {
      this.myProxy.getUser(this.userName, this.password).subscribe(user => {
        if (user!=false) {
          this.appService.CurrentUser = user as User;
          this.router.navigate(["/Home"]);
        }
        else {
          alert("User name or password is invalid!");
        }
      })

    }
    else {
      alert("User name or password is missing!");
    }
  }

  
  forgotId: string = "";
  isForgot:boolean=false;
  ForgotPassword() {
    if (this.forgotId != "") {
      this.myProxy.sendMailtoUser(this.forgotId).subscribe(x => {
        if (x==true) {
          this.dialog.open(AlertDialogComponent,
            {
              width: '35vw',
              data: { msg: "We sent you an email! please check your mail box." }
            }
          );
        }
        else {
          this.dialog.open(AlertDialogComponent,
            {
              width: '35vw',
              data: { msg: "User not found!!!" }
            }
          );
        }

      })
    }
  }

  register() {
    const dialogRef = this.dialog.open(RegisterDialogComponent,
      {
        width: '35vw',
        height: '37vh',
        data: {}
      }
    );
  }
}
