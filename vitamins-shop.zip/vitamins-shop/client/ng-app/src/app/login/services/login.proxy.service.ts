import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { User } from 'src/app/core/models/user';
 
@Injectable()
export class LoginProxyService {
 
  constructor(private _http: HttpClient) {}
  ServerPath="http://localhost:3000/";
  
  getUser(uName:string,pass:string) {
    return this._http.get(this.ServerPath+'getUser?uName='+uName+"&pass="+pass);
  }

  addUser(user:User) {
    return this._http.post(this.ServerPath+'addUser',{"user":user});
  }

  sendMailtoUser(id:string){
    return this._http.get(this.ServerPath+'sendmail?id='+id);
  }
}