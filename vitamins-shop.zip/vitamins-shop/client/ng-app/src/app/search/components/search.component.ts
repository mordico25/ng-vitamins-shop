import { AfterViewInit, Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { fromEvent } from 'rxjs';
import { map, debounceTime, distinctUntilChanged } from 'rxjs/operators';
import { AppService } from 'src/app/core/services/app.service';
import { Product } from 'src/app/products/models/Product';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit, AfterViewInit {

  constructor(private appService: AppService,
    private router: Router) { }
  ngAfterViewInit(): void {
    fromEvent(this.searchInput.nativeElement, "input")
      .pipe(
        map((event: Event) => (event.target as any).value)
        , debounceTime(500)
        , distinctUntilChanged()
      )
      .subscribe(val => {

        
        if (val != "") {
          this.filterProdutsList = this.appService.productList;
          this.filterProdutsList = this.filterProdutsList.filter(x => x.productName.indexOf(val) != -1);
        }
        else{
          this.filterProdutsList = [];
        }
      })
  }

  filterProdutsList: Product[] = [];
  @ViewChild("searchInput") searchInput: ElementRef;
  ngOnInit(): void {


  }

  gotoProduct(p: Product) {
    this.router.navigate(["/products/" + p.productId]);
  }
}
