import { NgModule } from '@angular/core';
import { CommonModule } from "@angular/common";
import { HttpClientModule } from "@angular/common/http";
import { FormsModule } from "@angular/forms";
import { TemplateComponentComponent } from './components/template-component/template-component.component';
import { NotFoundComponent } from './components/not-found/not-found.component';

@NgModule({
    declarations: [
     
    TemplateComponentComponent,
     
    NotFoundComponent],
    imports: [
        CommonModule,
        HttpClientModule,
        FormsModule,
    ],
    providers: []
  })
  export class AppModule { }