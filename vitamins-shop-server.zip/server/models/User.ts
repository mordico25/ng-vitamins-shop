export class User{
    ID:number;
    UserName:string;
    Password:string;
    Email:string;
    Address:string;
}