
import { User } from "./models/User";

export class UsersController
{
    getUsers():User[]{
        

    }
}