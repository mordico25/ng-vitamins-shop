import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { MCSearchComponent } from './search/search.component';

@NgModule({
  declarations: [
    AppComponent,
    MCSearchComponent
  ],
  imports: [
    BrowserModule,
  ],
  exports:[
    MCSearchComponent
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class MCModule { }
