import { EventEmitter } from '@angular/core';
import { AfterViewInit, Component, ElementRef, Input, OnInit, Output, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { fromEvent } from 'rxjs';
import { map, debounceTime, distinctUntilChanged } from 'rxjs/operators';


@Component({
  selector: 'mc-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class MCSearchComponent implements OnInit, AfterViewInit {

  @Input("itemsList") itemsList:any[];
  @Input("SearchFieldName") SearchFieldName:string;
  // @Input("RouteFieldName") RouteFieldName:string;
   @Output("filteredList") filteredList:EventEmitter<any[]>=new EventEmitter();

  constructor( 
    // private router: Router
    ) { }
  ngAfterViewInit(): void {
    fromEvent(this.searchInput.nativeElement, "input")
      .pipe(
        map((event: Event) => (event.target as any).value)
        , debounceTime(500)
        , distinctUntilChanged()
      )
      .subscribe(val => {

        
        if (val != "") {
          this.filterProdutsList = this.itemsList;
          this.filterProdutsList = this.filterProdutsList.filter(x => x[this.SearchFieldName].indexOf(val) != -1);
        }
        else{
          this.filterProdutsList = [];
        }
        this.filteredList.emit(this.filterProdutsList);
      })
  }

  filterProdutsList: any[] = [];
  @ViewChild("searchInput") searchInput: ElementRef;
  ngOnInit(): void {


  }

  gotoProduct(item: any) {
    // this.router.navigate([item[this.RouteFieldName]]);
  }
}
